//Biblioteca para inicializar e com rptinas para controlar o teclado matricial

#ifndef CONTROL_KEYBOARD_H
#define CONTROL_KEYBOARD_H

// #define ROW1 18  // R1 -> GP8
// #define ROW2 19  // R2 -> GP7
// #define ROW3 20  // R3 -> GP6
// #define ROW4 4  // R4 -> GP5

// #define COL1 9    // C1 -> GP4
// #define COL2 8   // C2 -> GP3
// #define COL3 16   // C3 -> GP2
// #define COL4 17  // C4 --> GP0

const int row_pins[4] = {18, 19, 20, 4};
const int col_pins[4] = {9, 8, 16, 17};

const char keymap[4][4] = {
    {'1', '2', '3', 'A'},
    {'4', '5', '6', 'B'},
    {'7', '8', '9', 'C'},
    {'*', '0', '#', 'D'}
};

// Inicializa os pinos do teclado matricial
void init_keyboard() {
    // // Inicializa as linhas como saída
    // gpio_init(ROW1);
    // gpio_init(ROW2);
    // gpio_init(ROW3);
    // gpio_init(ROW4);

    // gpio_set_dir(ROW1, GPIO_OUT);
    // gpio_set_dir(ROW2, GPIO_OUT);
    // gpio_set_dir(ROW3, GPIO_OUT);
    // gpio_set_dir(ROW4, GPIO_OUT);

    // // Inicializa as colunas como entrada com *pull-down*
    // gpio_init(COL1);
    // gpio_init(COL2);
    // gpio_init(COL3);
    // gpio_init(COL4);

    // gpio_set_dir(COL1, GPIO_IN);
    // gpio_set_dir(COL2, GPIO_IN);
    // gpio_set_dir(COL3, GPIO_IN);
    // gpio_set_dir(COL4, GPIO_IN);

    // gpio_pull_down(COL1);
    // gpio_pull_down(COL2);
    // gpio_pull_down(COL3);
    // gpio_pull_down(COL4);

    // gpio_put(ROW1,0);
    // gpio_put(ROW2,0);
    // gpio_put(ROW3,0);
    // gpio_put(ROW4,0);

    // Inicializa as linhas e colunas do teclado
    for (int i = 0; i < 4; i++) {  // Itera sobre cada linha do teclado.
        gpio_init(row_pins[i]);       // Inicializa o pino da linha atual.
        gpio_set_dir(row_pins[i], GPIO_OUT); // Define o pino como saída.
        gpio_put(row_pins[i], 1);     // Define o pino como alto (1).
    }

    for (int i = 0; i < 4; i++) {  // Itera sobre cada coluna do teclado.
        gpio_init(col_pins[i]);       // Inicializa o pino da coluna atual.
        gpio_set_dir(col_pins[i], GPIO_IN);  // Define o pino como entrada.
        gpio_pull_up(col_pins[i]);    // Ativa o resistor de pull-up no pino.
    }
}

// Lê a tecla pressionada no teclado matricial
// Verifica qual tecla foi pressionada
char ler_teclado() {
    for (int row = 0; row < 4; row++)
    {
        gpio_put(row_pins[row], 0);
        sleep_ms(5);

        for (int col = 0; col < 4; col++) 
        {
            if (gpio_get(col_pins[col]) == 0)
            {
                while (gpio_get(col_pins[col]) == 1); // Aguarda até que a tecla seja liberada
                gpio_put(row_pins[row], 1); // Restaura a coluna para nível lógico alto
                return keymap[row][col]; // Retorna a tecla correspondente
            }
        }
        gpio_put(row_pins[row], 1);
    }

    return '\0'; // Nenhuma tecla foi pressionada
}

#endif
